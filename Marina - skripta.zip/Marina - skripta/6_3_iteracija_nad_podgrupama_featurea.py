lejer = iface.activeLayer()

# vrsi iteraciju nad podskupom feature-a
# unutar odredjenog prostora
podrucjeInteresa = QgsRectangle(7367588,4942951, 7373452,4937995)
request = QgsFeatureRequest().setFilterRect(podrucjeInteresa)

for feature in lejer.getFeatures(request):
    if feature[6] < 50.0:
        print('Povrsina poligona je manja od 50km kvadratnih')
    else:
        print('Povrsina poligona je veca od 50km kvadratnih')

# moguce je postaviti limit koliko feature-a
# zelimo da bude vraceno
request.setLimit(2)
for feature in lejer.getFeatures(request):
    print(feature)
    

# ukoliko zelimo da izvrsimo iteraciju i filtriranje na osnovu
# odredjenog atributa, tu mozemo iskoristimo QgsExpression objekat
# i da ga prosledimo QgsFeatureRequest konstruktoru
izraz = QgsExpression('Nagib > 0.5')
request = QgsFeatureRequest(izraz)

for feature in lejer.getFeatures(request):
    print(feature[1])
    
# jos neke korisne metode, namerno stavljene kao varijable
# vraca samo izabrane atribute, kako bi se ubrzao zahtev
x = request.setSubsetOfAttributes([1,6])

# drugi nacin
y = request.setSubsetOfAttributes(['OpisStari', 'povrsina'], lejer.fields())

# ne vraca objekte geometrije, kako bi se dodatno ubrzao zahtev
z = request.setFlags(QgsFeatureRequest.NoGeometry)

# vraca samo feature sa specificno navedenim ID
c = request.setFilterFid(9)

# moguce je odredjene opcije povezati i iskoristiti istovremeno
request.setFilterRect(podrucjeInteresa).setFlags(QgsFeatureRequest.NoGeometry).setFilterFid(1). \
setSubsetOfAttributes([1,6])

for feature in lejer.getFeatures(request):
    print(feature[1] + ' ' + str(feature[6]))
