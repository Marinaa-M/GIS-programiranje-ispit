
put_do_dema = 'D:/Diplomski_rad/DEM_Granica_opstine.tif'

rlayer = QgsRasterLayer(put_do_dema, 'DEM')

# Prvo se dodaje lejer, bez "pokazivanja"
QgsProject.instance().addMapLayer(rlayer, False)
# Pristupa se "stablu" lejera koji je na vrhu projekta
layerTree = iface.layerTreeCanvasBridge().rootGroup()
# Pozicija se definise kao prvi argument (-1, za poslednje mesto)
layerTree.insertChildNode(-1, QgsLayerTreeLayer(rlayer))


# Ukoliko zelimo da uklonimo lejer
# QgsProject.instance().removeMapLayer(rlayer.id())

# Ukoliko zelimo da izlistamo ucitana lejere i njihove ID-e
# QgsProject.instance().mapLayers()
