import os
#from qgis.core import(QgsVectorLayer) - ukoliko je standalone

#putanja do gpkg
put_do_corine = os.path.join(QgsApplication.pkgDataPath(), 'resources', 'data', 'D:/Diplomski_rad/CORINE2012NOVO.gpkg')

vlayer = QgsVectorLayer(put_do_corine, 'CORINE2012NOVO.gpkg', 'ogr')

if not vlayer.isValid():
    print("Lejer nije uspesno ucitan")
else:
    QgsProject.instance().addMapLayer(vlayer)
