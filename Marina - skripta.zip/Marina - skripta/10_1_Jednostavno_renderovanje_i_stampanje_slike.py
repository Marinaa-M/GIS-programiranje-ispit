#Uzima odredjeni lejer i na osnovu njega kreira sliku

import os

lokacija_slike = os.path.join(QgsProject.instance().homePath(), "C:lokacija_slike = os.path.join(QgsProject.instance().homePath(), "D:/Geografski Fakultet OAS/Ekološki informacioni sistemi/Karte/Uredjene karte/Karta vegetacije i korišćenja zemljišta.png")
lejer = QgsProject.instance().mapLayersByName("CLCValjevo")[0]
settings = QgsMapSettings()
settings.setLayers([lejer])
settings.setBackgroundColor(QColor(255, 255, 255))
settings.setOutputSize(QSize(800, 600))
settings.setExtent(lejer.extent())

render = QgsMapRendererParallelJob(settings)

def zavrsen():
    slika = render.renderedImage()
    #Čuvanje slike
    slika.save(lokacija_slike, "png")

render.finished.connect(zavrsen)

#Započinje renderovanje
render.start()

#Ukoliko je standalone skripta, neophodno je importovati ovaj modul zbog specifične petlje (pošto je ova skripta pisana da se pokreće
#unutar samog QGIS-a, nema potrebe da se importuje)
# from qgis.PyQt5.QtCore import QEventLoop
petlja = QEventLoop()
render.finished.connect(petlja.quit)
petlja.exec_()

#Ukoliko imamo više različitih lejera, u različitim koordinatnim sistemima neophodno je da namestimo koordinatni sistem u kom želimo da lejer bude prikazan
# lejeri = [iface.activeLayer()]
# settings.setLayers(lejeri)
# settings.setDestinationCrs(lejeri[0].crs())
