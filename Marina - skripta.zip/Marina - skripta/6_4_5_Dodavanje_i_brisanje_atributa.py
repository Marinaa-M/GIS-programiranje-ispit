# from qgis.PyQt.QtCore import QVariant (ukoliko smo izvan qgis-a)

#Korišćeni lejer = Korina Valjevo
lejer = iface.activeLayer()
caps = lejer.dataProvider().capabilities()

#Dodaje atribute izabranom lejeru
if caps and QgsVectorDataProvider.AddAttributes:
    res = lejer.dataProvider().addAttributes(
    [QgsField("Opis", QVariant.String),
    QgsField("Povrs_ha", QVariant.Int)])

#Briše atribut na osnovu njegovog indeksa
#Ukloniti '#' da bi se izvršilo brisanje
#if caps and QgsVectorDataProvider.DeleteAttributes:
    # res = lejer.dataProvider().deleteAttributes([4])  

#Štampa atribute koji su trenutno dodeljeni lejeru
for atribut in lejer.fields():
    print(atribut.name())
print('--------------------------')
count = lejer.fields().count() #Vraća broj atributa u lejeru
lista_indeksa = list((count-3, count-2))

#Briše jedan atribut pomoću indeksa
lejer.dataProvider().deleteAttributes([count-1])

#Briše visš atributa pomoću liste sa indeksima
lejer.dataProvider().deleteAttributes(lista_indeksa)
lejer.updateFields()

for atribut in lejer.fields():
    print(atribut.name())
