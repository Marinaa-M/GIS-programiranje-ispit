# Pristupanje root-u u legendi (TOC-u) i manipulisanje lejerima u njoj
# Vise opisano na https://www.lutraconsulting.co.uk/blog/2014/07/25/qgis-layer-tree-api-part-2/


# Instanciranje root-a (pocetnog cvora) od lejera u legendi (TOC-u)
root = QgsProject.instance().layerTreeRoot()

# root je grupni cvor i ima "decu"
root.children()

dete0 = root.children()[0]
print(dete0)

# Lejerima se takodje moze pristupiti pomocu unikatnog ID-ja
ids = root.findLayerIds()
x = root.findLayer(ids[0])
print(x)

# Takodje, grupe isto mogu da se pretrazuju pomocu naziva
root.findGroup('Solarni_paneli')

# Izbacuje listu svih lejera koji su "stiklirani"
stiklirani_lejeri = root.checkedLayers()
print(stiklirani_lejeri)
