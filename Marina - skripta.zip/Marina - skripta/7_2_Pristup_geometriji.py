'''from qgis.core import (
  QgsGeometry,
  QgsPoint,
  QgsPointXY,
  QgsWkbTypes,
  QgsProject,
  QgsFeatureRequest,
  QgsVectorLayer,
  QgsDistanceArea,
  QgsUnitTypes,
  QgsCoordinateTransform,
  QgsCoordinateReferenceSystem
)''' 

#Kreiranje geometrije iz koordinata
gTacka = QgsGeometry.fromPointXY(QgsPointXY(7367975,4941647))
print(gTacka)

gLinija = QgsGeometry.fromPolyline([QgsPoint(7365894,4949697), QgsPoint(7369230,4935285)])
print(gLinija)

gPoligon = QgsGeometry.fromPolygonXY([
[QgsPointXY(7359602,4927949), 
QgsPointXY(7366506,4929147),
QgsPointXY(7364291.3,4924586.2)]
])
print(gPoligon)

#Proverava tip geometrije
if gTacka.wkbType() == QgsWkbTypes.Point:
    print(gTacka.wkbType())
    #Izlaz: 1 za tačku
    
if gLinija.wkbType() == QgsWkbTypes.LineString:
    print(gLinija.wkbType())
    #Izlaz: 2 za liniju
    
if gPoligon.wkbType() == QgsWkbTypes.Polygon:
    print(gPoligon.wkbType())
    #Izlaz: 3 za poligon
print('--------------------------------')

#Alternativni način
print(QgsWkbTypes.displayString(gTacka.wkbType()))
#Izlaz: Point
print(QgsWkbTypes.displayString(gLinija.wkbType()))
#Izlaz: LineString
print(QgsWkbTypes.displayString(gPoligon.wkbType()))
print('--------------------------------')

#Proverava da li je geometrija sastavljena iz više delova ili ne
print(gTacka.isMultipart())
print('--------------------------------')

#Metode za pristup svakom vektorskom tipu torke predstavljanje u vidu XY koordinata nisu prave torke već QgsPoint objekti, čijim
#vrednostima se može pristupiti pomocu x() i y() metodama
print(gTacka.asPoint())
print(gLinija.asPolyline())
print(gPoligon.asPolygon())

#Za multipart geometrije to su: asMultiPoint(), asMultiPolyline(), asMultiPolygon()
print('--------------------------------')

#Vrši iteraciju nad svim delovima geometrije
for deo in gPoligon.parts():
    print(deo.asWkt())

#Vrši transformaciju svakog dela geometrije
for deo in gTacka.parts():
    deo.transform(QgsCoordinateTransform(
    QgsCoordinateReferenceSystem('EPSG:6316'),
    QgsCoordinateReferenceSystem('EPSG:32634'),
    QgsProject.instance())
    )
print(gTacka.asWkt())
