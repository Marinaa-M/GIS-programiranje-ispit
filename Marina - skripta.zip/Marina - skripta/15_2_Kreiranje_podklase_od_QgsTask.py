import random
from time import sleep

'''from qgis.core import (
    QgsApplication, QgsTask, QgsMessageLog,
    )'''  #Ukoliko je standalone
    
MESSAGE_CATEGORY = 'RandomIntegerSumTask'

class RandomIntegerSumTask(QgsTask):
    #Pokazuje kako možemo da napravimo podklasu od QgsTask klase
    
    def __init__(self, description, trajanje):
        super().__init__(description, QgsTask.CanCancel)
        self.trajanje = trajanje
        self.ukupno = 0
        self.iteracije = 0
        self.izuzetak = None
    
    def run(self):
        QgsMessageLog.logMessage('Task zapocet: {}'.format(self.description()), MESSAGE_CATEGORY, Qgis.Info)
        wait_time = self.trajanje/100
        for i in range(100):
            sleep(wait_time)
            #setProgress se koristi da bi se prijavio napredak
            task.setProgress(1)
            randomint = random.randint(0, 500)
            self.ukupno += randomint
            self.iteracije += 1
            #proverava task.isCanceled() kako bi postupio sa prekidanjem
            if self.isCanceled():
                return False
            #simulira izuzetke, da bi se prikazalo kako se prekida task
            if randomint == 54:
                #Ne podizi Exception('Losa vrednost')
                #ovo bi dovelo do prestanka rada QGIS-a
                self.izuzetak = Exception('Losa Vrednost!')
                return False
        return True

    def zavrsen(self, rezultat):
        if rezultat:
            QgsMessageLog.LogMessage(
            'Random task "{}" izvrsen\n'\
            'Random ukupno "{}" (sa ukupnim brojem {} iteracija)'.format(
            self.description(),
            self.ukupno,
            self.iteracije),
            MESSAGE_CATEGORY, Qgis.Success)
        else:
            if self.izuzetak is None:
                QgsMessageLog.logMessage(
                'Random task "{}" nije uspeo, ali bez podizanja izuzetka'\
                '(task je verovatno prekinut od strane korisnika)'.format(
                self.description()), MESSAGE_CATEGORY, Qgis.Warning)
            else:
                QgsMessageLog.logMessage(
                'Random task "{}" izuzetak: {}.'.format(
                self.description(), self.izuzetak),
                MESSAGE_CATEGORY, Qgis.Critical)
                raise self.izuzetak
        
    def prekini(self):
        QgsMessageLog.logMessage(
        'Random task "{}" je prekinut'.format(self.description()),
        MESSAGE_CATEGORY, Qgis.Info)
        super().cancel()