'''from qgis.core import (
    QgsRasterLayer,
    QgsProject,
    QgsPointXY,
    QgsRaster,
    QgsRasterShader,
    QgsColorRampShader,
    QgsSingleBandPseudoColorRenderer,
    QgsSingleBandColorDataRenderer,
    QgsSingleBandGrayRenderer,
)

from qgis.PyQt.QtGui import (
    QColor,
)'''

raster = QgsProject.instance().mapLayersByName('DEM_Granica_opstine')[0]
# vraca rezoluciju rastera
print(raster.width(), raster.height())
# vraca x i y koordinate rastera kao stringove
print(raster.extent().toString())
# vraca tip raster: 0 = grayscale (1 kanal), 1 = paleta (1 kanal)
# 2 = vise kanala (multiband)
print(raster.rasterType())
# vraca broj kanala od rastera (za multispektralne snimke bi bilo vise)
print(raster.bandCount())
# vraca naziv prvog spektralnog kanala od rastera
print(raster.bandName(1))
# vraca metapodatke od rastera kao QgsLayerMetadata objekat
print(raster.metadata())
