# from qgis.PyQt5.QtCore import import QVariant - ukoliko je standalone

#Kreira se lejer 
lejer = QgsVectorLayer("Point", "Privremena tacka", "memory")
priv = lejer.dataProvider()

#Dodavanje atributa
priv.addAttributes(
[QgsField("Objekat", QVariant.String),
QgsField("Visina", QVariant.Int),
QgsField("Sirina", QVariant.Double)]
)

lejer.updateFields() #Obavestava vektorski lejer da ažurira promene od provajdera

#Dodavanje feature-a
feat = QgsFeature()
feat.setGeometry(QgsGeometry.fromPointXY(QgsPointXY(7367413,4940679)))
feat.setAttributes(["Gradska uprava", 35, 20.2])
priv.addFeatures([feat])

#Ažurira obim lejera kada su dodati novi feature-i
#pošto se promena obima provajdera ne odražava direktno na lejer
lejer.updateExtents 

print('fields: ', len(priv.fields()))
print('features: ', priv.featureCount())
e = lejer.extent()
print('obim: ', e.xMinimum(), e.yMinimum(), e.xMaximum(), e.yMaximum())

#Vrši iteraciju nad feature-ima
features = lejer.getFeatures()
for feat in features:
    print('F: ', feat.id(), feat.attributes(), feat.geometry().asPoint())
