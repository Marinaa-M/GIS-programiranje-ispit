'''from qgis.core import (
    edit,
    QgsExpression,
    QgsExpressionContext,
    QgsFeature,
    QgsFeatureRequest,
    QgsField,
    QgsFields,
    QgsVectorLayer,
    QgsPointXY,
    QgsGeometry,
    QgsProject,
    QgsExpressionContextUtils
)''' #Ukoliko je standalone skripta


#Ukoliko želimo da proverimo da li izraz moze biti uspešno rastavljen
#Odnosno da li je ispravan; ukoliko nije, bice izbačen AssertionError
# exp = QgsExpression('1 + 1 = 2')
# assert(not exp.hasParserError())

# exp = QgsExpression('1 + 1 = ')
# assert(exp.hasParserError())

# assert(exp.parserErrorString() == '\nsyntax error, unexpected $end')

#Obični izrazi
izraz = QgsExpression('5*4')
print(izraz)
print(izraz.evaluate())

#Takodje se mogu koristiti za uporedjivanje: 1 je True, 0 je False
izraz = QgsExpression("3+2=5")
print(izraz.evaluate())
print('-----------------------------')

#Kreira atribut 'povrs_ha', koji se odnosi na povrsinu u hektarima
atributi = QgsFields()
atribut = QgsField("Kolona")
atributi.append(atribut)
feature = QgsFeature()
feature.setFields(atributi)
feature.setAttribute(0, 99)

izraz = QgsExpression('"Kolona"')
context = QgsExpressionContext()
context.setFeature(feature)
print(izraz.evaluate(context))
print('----------------------------')


'''lejer = QgsProject.instance().mapLayersByName("CLCValjevo")[0]
lejer.startEditing()

izraz = 'povrsina >= 30'
zahtev = QgsFeatureRequest().setFilterExpression(izraz)

matches = 0
for f in lejer.getFeature(zahtev):
    matches += 1

print(matches)'''

lejer = QgsVectorLayer("Point?field=Test:integer",
                           "addfeat", "memory")

lejer.startEditing()

for i in range(10):
    feature = QgsFeature()
    feature.setAttributes([i])
    assert(lejer.addFeature(feature))
lejer.commitChanges()

izraz = "Test >= 3"
zahtev = QgsFeatureRequest().setFilterExpression(izraz)

matches = 0
for f in lejer.getFeatures(zahtev):
   matches += 1
print(matches)