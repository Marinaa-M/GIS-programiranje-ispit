from qgis.PyQt import QtGui

#Korišćeni lejer: Naselja Valjevo
lejer = iface.activeLayer()
atribut = "br_st"
opseg = []
prozirnost = 1

#Kreira se prvi simbol i opseg
min = 250
max = 850
naziv = "250-850"
boja = QtGui.QColor("#ff01c4")
prvi_simbol = QgsSymbol.defaultSymbol(lejer.geometryType())
prvi_simbol.setColor(boja)
prvi_simbol.setOpacity(prozirnost)
prvi_opseg = QgsRendererRange(min, max, prvi_simbol, naziv)
opseg.append(prvi_opseg)

#Drugi simbol
min = 850
max = 2100
naziv = "850-2100"
boja = QtGui.QColor("#01ffdd")
drugi_simbol = QgsSymbol.defaultSymbol(lejer.geometryType())
drugi_simbol.setColor(boja)
drugi_simbol.setOpacity(prozirnost)
drugi_opseg = QgsRendererRange(min, max, drugi_simbol, naziv)
opseg.append(drugi_opseg)

renderer = QgsGraduatedSymbolRenderer('', opseg)
metod_klasifikacije = QgsApplication.classificationMethodRegistry().method("EqualInterval")
renderer.setClassificationMethod(metod_klasifikacije)
renderer.setClassAttribute(atribut)

lejer.setRenderer(renderer)
lejer.triggerRepaint()
